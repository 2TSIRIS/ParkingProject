/* - LCDDetachListener -
 * We will display the device detach status and clear all the other fields
 *
 * Copyright 2011 Phidgets Inc.
 * This work is licensed under the Creative Commons Attribution 2.5 Canada License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by/2.5/ca/
 */
package listeners;

import com.phidgets.*;
import com.phidgets.event.*;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class LCDDetachListener implements DetachListener {

    private JFrame appFrame;
    private JTextField attachedTxt;
    private JTextArea nameTxt;
    private JTextField serialTxt;
    private JTextField versionTxt;
    private JTextField dispTxt1;
    private JTextField dispTxt2;
    private JTextField dispTxt3;
    private JTextField dispTxt4;
    private JCheckBox backlightChk;
    private JCheckBox cursorChk;
    private JCheckBox blinkChk;
    private JCheckBox customChk;
    private JSlider contrastSlide;
    private JSlider brightnessSlide;
    private JComboBox screenCmb;
    private JComboBox screenSizeCmb;
    private JButton initializeBtn;

    /** Creates a new instance of LCDDetachListener */
    public LCDDetachListener(JFrame appFrame, JTextField attachedTxt, JTextArea nameTxt,
            JTextField serialTxt, JTextField versionTxt, JTextField dispTxt1,
            JTextField dispTxt2, JTextField dispTxt3, JTextField dispTxt4, JCheckBox backlightChk,
            JCheckBox cursorChk, JCheckBox blinkChk, JCheckBox customChk,
            JSlider contrastSlide, JSlider brightnessSlide, JComboBox screenCmb, JComboBox screenSizeCmb, JButton initializeBtn) {
        this.appFrame = appFrame;
        this.attachedTxt = attachedTxt;
        this.nameTxt = nameTxt;
        this.serialTxt = serialTxt;
        this.versionTxt = versionTxt;
        this.dispTxt1 = dispTxt1;
        this.dispTxt2 = dispTxt2;
        this.dispTxt3 = dispTxt3;
        this.dispTxt4 = dispTxt4;
        this.backlightChk = backlightChk;
        this.cursorChk = cursorChk;
        this.blinkChk = blinkChk;
        this.customChk = customChk;
        this.contrastSlide = contrastSlide;
        this.brightnessSlide = brightnessSlide;
        this.screenCmb = screenCmb;
        this.screenSizeCmb = screenSizeCmb;
        this.initializeBtn = initializeBtn;
    }

    public void detached(DetachEvent ae) {
        try {
            TextLCDPhidget detached = (TextLCDPhidget) ae.getSource();
            attachedTxt.setText(Boolean.toString(detached.isAttached()));
            nameTxt.setText("");
            serialTxt.setText("");
            versionTxt.setText("");
            dispTxt1.setText("");
            dispTxt1.setEnabled(false);
            dispTxt2.setText("");
            dispTxt2.setEnabled(false);
            dispTxt3.setText("");
            dispTxt3.setEnabled(false);
            dispTxt4.setText("");
            dispTxt4.setEnabled(false);
            backlightChk.setSelected(false);
            backlightChk.setEnabled(false);
            cursorChk.setSelected(false);
            cursorChk.setEnabled(false);
            blinkChk.setSelected(false);
            blinkChk.setEnabled(false);
            customChk.setSelected(false);
            customChk.setEnabled(false);
            contrastSlide.setEnabled(false);
            brightnessSlide.setEnabled(false);
            screenCmb.setEnabled(false);
            screenSizeCmb.setEnabled(false);
            initializeBtn.setEnabled(false);

            screenCmb.setEnabled(false);
            screenCmb.removeAllItems();

            screenSizeCmb.setEnabled(false);
            screenSizeCmb.removeAllItems();

        } catch (PhidgetException ex) {
            JOptionPane.showMessageDialog(appFrame, ex.getDescription(), "Phidget error " + ex.getErrorNumber(), JOptionPane.ERROR_MESSAGE);
        }
    }
}
