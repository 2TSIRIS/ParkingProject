/* - MCDetachListener -
 * Clear all the fields and disable all the controls
 *
 * Copyright 2007 Phidgets Inc.  
 * This work is licensed under the Creative Commons Attribution 2.5 Canada License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by/2.5/ca/
 */
package listeners;

import com.phidgets.MotorControlPhidget;
import com.phidgets.PhidgetException;
import com.phidgets.event.DetachListener;
import com.phidgets.event.DetachEvent;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class MCDetachListener implements DetachListener {

    private JFrame appFrame;
    private JTextField attachedTxt;
    private JTextArea nameTxt;
    private JTextField serialTxt;
    private JTextField versionTxt;
    private JTextField numMotorsTxt;
    private JTextField numInTxt;
    private JTextField numEncodersTxt;
    private JTextField numSensorsTxt;
    private JTextField tarVelTxt;
    private JTextField maxVelTxt;
    private JTextField accelTxt;
    private JTextField currentTxt;
    private JComboBox motorCmb;
    private JSlider maxVelScrl;
    private JSlider accelScrl;
    private JSlider brakeScrl;
    private JLabel jLabel19;
    private JCheckBox inputArray[];
    private JLabel jLabel10;
    private JTextField brakeTxt;
    private JLabel jLabel16;
    private JTextField supplyVoltageTxt;
    private JLabel jLabel18;
    private JCheckBox backEMFChk;
    private JTextField backEMFTxt;
    private JLabel jLabel17;
    private JLabel sensorLabel[];
    private JTextField sensorArray[];
    private JCheckBox ratiometricChk;
    private JLabel encoderLabel[];
    private JTextField encoderArray[];
    private JPanel inputPanel;
    private JPanel sensorPanel;
    private JPanel encoderPanel;

    /** Creates a new instance of MCDetachListener */
    public MCDetachListener(JFrame appFrame, JTextField attachedTxt, JTextArea nameTxt,
            JTextField serialTxt, JTextField versionTxt, JTextField numMotorsTxt, JTextField numInTxt,
            JTextField numEncodersTxt, JTextField numSensorsTxt, JTextField tarVelTxt, JTextField maxVelTxt, JTextField accelTxt,
            JLabel jLabel10, JTextField currentTxt, JComboBox motorCmb, JSlider maxVelScrl,
            JSlider accelScrl, JSlider brakeScrl, JCheckBox inputArray[], JTextField brakeTxt, JLabel jLabel16, JTextField supplyVoltageTxt,
            JLabel jLabel18, JCheckBox backEMFChk, JTextField backEMFTxt, JLabel jLabel17, JLabel sensorLabel[], JTextField sensorArray[],
            JLabel encoderLabel[], JTextField encoderArray[], JLabel jLabel19, JPanel inputPanel, JPanel sensorPanel, JPanel encoderPanel,
            JCheckBox ratiometricChk) {
        this.appFrame = appFrame;
        this.attachedTxt = attachedTxt;
        this.nameTxt = nameTxt;
        this.serialTxt = serialTxt;
        this.versionTxt = versionTxt;
        this.numMotorsTxt = numMotorsTxt;
        this.numInTxt = numInTxt;
        this.numEncodersTxt = numEncodersTxt;
        this.numSensorsTxt = numSensorsTxt;
        this.tarVelTxt = tarVelTxt;
        this.maxVelTxt = maxVelTxt;
        this.accelTxt = accelTxt;
        this.jLabel10 = jLabel10;
        this.currentTxt = currentTxt;
        this.motorCmb = motorCmb;
        this.maxVelScrl = maxVelScrl;
        this.accelScrl = accelScrl;
        this.brakeScrl = brakeScrl;
        this.jLabel19 = jLabel19;
        this.inputArray = inputArray;
        this.brakeTxt = brakeTxt;
        this.jLabel16 = jLabel16;
        this.supplyVoltageTxt = supplyVoltageTxt;
        this.jLabel18 = jLabel18;
        this.backEMFChk = backEMFChk;
        this.backEMFTxt = backEMFTxt;
        this.jLabel17 = jLabel17;
        this.sensorLabel = sensorLabel;
        this.sensorArray = sensorArray;
        this.ratiometricChk = ratiometricChk;
        this.encoderLabel = encoderLabel;
        this.encoderArray = encoderArray;
        this.inputPanel = inputPanel;
        this.sensorPanel = sensorPanel;
        this.encoderPanel = encoderPanel;
    }

    public void detached(DetachEvent de) {
        try {
            MotorControlPhidget detached = (MotorControlPhidget) de.getSource();
            attachedTxt.setText(Boolean.toString(detached.isAttached()));
            nameTxt.setText("");
            serialTxt.setText("");
            versionTxt.setText("");
            numMotorsTxt.setText("");
            numInTxt.setText("");
            numEncodersTxt.setText("");
            numSensorsTxt.setText("");

            tarVelTxt.setText("");
            maxVelTxt.setText("");
            maxVelScrl.setValue(0);
            maxVelScrl.setEnabled(false);

            accelTxt.setText("");
            accelScrl.setValue(1);
            accelScrl.setEnabled(false);

            brakeTxt.setText("");
            brakeTxt.setEnabled(false);
            jLabel16.setEnabled(false);
            supplyVoltageTxt.setText("");
            supplyVoltageTxt.setEnabled(false);
            backEMFChk.setEnabled(false);
            backEMFTxt.setEnabled(false);
            backEMFChk.setText("");
            backEMFTxt.setText("");

            brakeScrl.setValue(0);
            brakeScrl.setEnabled(false);
            jLabel10.setEnabled(false);
            brakeTxt.setText("");
            brakeTxt.setEnabled(false);


            currentTxt.setText("");
            currentTxt.setEnabled(false);

            motorCmb.setEnabled(false);
            motorCmb.setSelectedIndex(0);
            motorCmb.removeAllItems();


            int i;
            for (i = 0; i < 4; i++) {
                inputArray[i].setVisible(false);
            }

            inputPanel.setVisible(false);
            sensorPanel.setVisible(false);
            encoderPanel.setVisible(false);

            appFrame.setSize(357, 670);


        } catch (PhidgetException ex) {
            JOptionPane.showMessageDialog(appFrame, ex.getDescription(), "Phidget error " + ex.getErrorNumber(), JOptionPane.ERROR_MESSAGE);
        }
    }
}
