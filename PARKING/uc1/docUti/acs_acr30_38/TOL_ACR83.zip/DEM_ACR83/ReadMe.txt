ACR83 Evaluation Package
Advanced Card Systems Ltd.

Contents
----------------

   1. Release Notes
   2. Installation
   3. History
   4. File Contents
   5. Limitations
   6. Support



1. Release Notes
----------------

Version: 1.0.0.3
Release date: 17/6/2008



2. Installation
---------------

Please refer to the user guide in "doc\ACR83 Demo Program User Guide v1.3.pdf" for the installation procedures.



3. History
----------

1.0.0.3     New Release



4. File Contents
----------------

|   ReadMe.txt
|
+---demo
|       a83usb.inf
|       a83usb.sys
|       acos2_option.txt
|       acos2_script.txt
|       ACR83_Demo.exe
|
\---doc
        ACR83 Demo Program User Guide v1.3.pdf
        


5. Limitations
--------------



6. Support
----------

In case of problem, please contact ACS through:

Web Site: http://www.acs.com.hk/
E-mail: info@acs.com.hk
Tel: +852 2796 7873
Fax: +852 2796 1286



-----------------------------------------------------------------


Copyright 
Copyright by Advanced Card Systems Ltd. (ACS) No part of this reference manual may be reproduced or transmitted in any from without the expressed, written permission of ACS. 

Notice 
Due to rapid change in technology, some of specifications mentioned in this publication are subject to change without notice. Information furnished is believed to be accurate and reliable. ACS assumes no responsibility for any errors or omissions, which may appear in this document. 
