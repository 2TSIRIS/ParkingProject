/*******************************************************************************
njc 13/11/2005
*******************************************************************************/

#include "serial.h"
#include <windows.h>
#include <stdio.h>

HANDLE hSerial;

/*****************************************************************************/
int WriteCom (LPCVOID lpBuffer, DWORD dwNbByte)
{
	DWORD dwWritten;

	if (!WriteFile (hSerial,lpBuffer,dwNbByte,&dwWritten,0))
		return -1;

	return (int) dwWritten;

} /* WriteCom */

/*****************************************************************************/
int ReadCom  (LPVOID  lpBuffer, DWORD dwNbByte)
{
	DWORD dwRead;

	if (!ReadFile (hSerial,lpBuffer,dwNbByte,&dwRead,0))
		return -1;

	return dwRead;
} /* ReadCom */

/*****************************************************************************/
int InitSerial()
{
	DCB dcb;
	const int TIME_OUT = 100;
	COMMTIMEOUTS stTime;

	hSerial = CreateFile
					("COM1",GENERIC_READ | GENERIC_WRITE,
					0,	// comm devices must be opened w/exclusive-access
					NULL,	// no security attributes
					OPEN_EXISTING,// comm devices must use OPEN_EXISTING
					0,	// not overlapped I/O
					NULL	// hTemplate must be NULL for comm devices
					);

	
	if (hSerial  == INVALID_HANDLE_VALUE)
	{ // Handle the error.
		printf ("GetCommOpen failed with error %d.\n", GetLastError());
		return -1;
	}

	stTime.ReadIntervalTimeout = TIME_OUT;
	stTime.ReadTotalTimeoutConstant = TIME_OUT;
	stTime.ReadTotalTimeoutMultiplier = TIME_OUT;
	stTime.WriteTotalTimeoutConstant = TIME_OUT;
	stTime.WriteTotalTimeoutMultiplier = TIME_OUT;

	SetCommTimeouts (hSerial, &stTime);

	// Configuring the device
	dcb.BaudRate = CBR_9600;
	dcb.ByteSize = 8;
	dcb.Parity = NOPARITY;  
	dcb.StopBits = ONESTOPBIT;

	PurgeComm (hSerial,
		PURGE_TXABORT|PURGE_RXABORT|PURGE_TXCLEAR|PURGE_RXCLEAR);
	printf ("Serial port successfully reconfigured.\n");


	return 0;
} /* InitSerial */

/*****************************************************************************/
void CloseSerial(HANDLE hSerial)
{
	CloseHandle(hSerial);
} /* CloseSerial */

