#include <stdio.h>

#include "serial.h"

char buffer[5],trame[60];

char cold_reset[15]={'6','0','0','4','6','E','0','1','0','0','0','0','0','B',3};
char con_lect[9]={'6','0','0','1','4','D','2','C',3};
char lectmot_280[19]={'6','0','0','6','D','B','B','C','B','0', '0','2', '8','0', '0','4','3','7',3};
	
int i;

int rec_flag;


void main (){
	InitSerial();

	printf("Trame envoyee: %s\n",con_lect);
	WriteCom(con_lect,9);
	while(buffer[0]!=3)
	{
		ReadCom(&buffer,1);
		trame[i]=buffer[0];
		i++;
	}
	trame[i]='\0';
	printf("Trame recu: %s\n",trame);

	i=0;
	trame[0]='\0';
    buffer[0]='\0';

	printf("Trame envoyee: %s\n",cold_reset);
	WriteCom(cold_reset,15);
	while(buffer[0]!=3)
	{
		ReadCom(&buffer,1);
		trame[i]=buffer[0];
		i++;
	}
	trame[i]='\0';
	printf("Trame recu: %s\n",trame);

	i=0;
	trame[0]='\0';
    buffer[0]='\0';

	printf("Trame envoyee: %s\n",lectmot_280);
	WriteCom(lectmot_280,19);
	while(buffer[0]!=3)
	{
		ReadCom(&buffer,1);
		trame[i]=buffer[0];
		i++;
	}
	trame[i]='\0';
	printf("Trame recu: %s\n",trame);

	i=0;
	trame[0]='\0';
    buffer[0]='\0';

	CloseSerial();

}