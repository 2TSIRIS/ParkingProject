/*******************************************************************************
njc 13/11/2005
*******************************************************************************/

#include <windows.h>

HANDLE hSerial;

int InitSerial();
int WriteCom (LPCVOID lpBuffer, DWORD dwNbByte);
int ReadCom  (LPVOID  lpBuffer, DWORD dwNbByte);
void CloseSerial();




