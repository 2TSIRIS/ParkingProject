#if !defined(AFX_SCARDMANAGER_H__70C53B1B_B3A2_411A_B9A7_89A489A06D5A__INCLUDED_)
#define AFX_SCARDMANAGER_H__70C53B1B_B3A2_411A_B9A7_89A489A06D5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SCardManager.h : header file
//

// PC/SC header files
#include "winscard.h"
#include "scarderr.h"

// these should be in scarderr.h...but they weren't
#define SCARD_E_NO_READERS_AVAILABLE  ((DWORD)0x8010002E)

/////////////////////////////////////////////////////////////////////////////
// SCardManager window

class SCardManager : public CWnd
{
// Construction
public:
	SCardManager();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(SCardManager)
	//}}AFX_VIRTUAL

// Implementation
public:
	CString m_GetPCSCErrorString(LONG);
	void m_FillReaderComboBox(CComboBox*);
	CString m_SelectedReader;
	SCARDHANDLE m_hCardHandle;
	LONG m_SCardConnect(LPCTSTR,CString);
	CString m_SCardListReaders();
	LONG m_SCardEstablishContext();
	LONG m_SCardReleaseContext();
	SCARDCONTEXT m_hSC;
	virtual ~SCardManager();

	// Generated message map functions
protected:
	CString m_csReaderList;
	//{{AFX_MSG(SCardManager)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCARDMANAGER_H__70C53B1B_B3A2_411A_B9A7_89A489A06D5A__INCLUDED_)
