// SCardManager.cpp : implementation file
//

#include "stdafx.h"
#include "TestPCSC.h"
#include "SCardManager.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// SCardManager
// when object is create establish the contenxt
SCardManager::SCardManager()
{
	m_SCardEstablishContext();
}

// when object is destroyed release the context
SCardManager::~SCardManager()
{
	m_SCardReleaseContext();
}


BEGIN_MESSAGE_MAP(SCardManager, CWnd)
	//{{AFX_MSG_MAP(SCardManager)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// SCardManager message handlers

LONG SCardManager::m_SCardEstablishContext()
{
	LONG            lReturn;

	MessageBox("Establishing Context","Info",MB_OK);
	// Establish the context.
	lReturn = SCardEstablishContext(SCARD_SCOPE_USER,
                                NULL,
                                NULL,
                                &m_hSC);
	if ( SCARD_S_SUCCESS != lReturn ) {
		printf("Failed to establish contenxt with SCardEstablishContext\n");
	}
	return lReturn;
}


LONG SCardManager::m_SCardReleaseContext()
{

	LONG lReturn;
	
	MessageBox("Releasing Context","Info",MB_OK);
	// Free the context.
	lReturn = SCardReleaseContext(m_hSC);
	if ( SCARD_S_SUCCESS != lReturn )
		printf("Failed SCardReleaseContext\n");

	return lReturn;
}


CString SCardManager::m_SCardListReaders()
{

	LPTSTR          pmszReaders = NULL;
	LONG            lReturn, lReturn2;
	DWORD           cch = SCARD_AUTOALLOCATE;

	// Retrieve the list the readers.
	// hSC was set by a previous call to SCardEstablishContext (during object creation).
	lReturn = SCardListReaders(m_hSC,
                           NULL,
                           (LPTSTR)&pmszReaders,
                           &cch );
	switch( lReturn )
	{
    case SCARD_E_NO_READERS_AVAILABLE:
		m_csReaderList = "No Readers Available";
        break;

    case SCARD_S_SUCCESS:
        // Do something with the multi string of readers.
        // A double-null terminates the list of values.
		m_csReaderList = pmszReaders;

        // Free the memory.
        lReturn2 = SCardFreeMemory(m_hSC,
                                   pmszReaders );

        if ( SCARD_S_SUCCESS != lReturn2 )
			MessageBox("Failed to free memory","Error",MB_OK);
			
		break;

	default:
		m_csReaderList = "SCardListReaders Failed";
        break;
	}
	return m_csReaderList;
}


LONG SCardManager::m_SCardConnect(LPCTSTR lpstReader, CString message)
{

	LONG            lReturn;
	DWORD           dwAP;

	// Connect to the reader.
	// hContext is a SCARDCONTEXT previously set by 
	// a call to SCardEstablishContext.

	MessageBox("Connecting to " + m_SelectedReader,"Reader",MB_OK);

	lReturn = SCardConnect( m_hSC, 
			              (LPCTSTR)m_SelectedReader,
			             SCARD_SHARE_SHARED,
			              SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,
			             &m_hCardHandle,
  			             &dwAP );
	
	if ( lReturn != SCARD_S_SUCCESS)
	{
		MessageBox((LPCTSTR)m_GetPCSCErrorString(lReturn),"Error",MB_OK);
	}


	// Use the connection; here we will merely display the
	// active protocol.
	switch ( dwAP )
	{
    case SCARD_PROTOCOL_T0:
        MessageBox("Active protocol T0","Protocol",MB_OK); 
        break;

    case SCARD_PROTOCOL_T1:
        MessageBox("Active protocol T1","Protocol",MB_OK); 
        break;

    case SCARD_PROTOCOL_UNDEFINED:
    default:
        MessageBox("Active protocol unnegotiated or unknown","Protocol",MB_OK); 
        break;
	}
	return lReturn;
}

void SCardManager::m_FillReaderComboBox(CComboBox *combobox)
{
	LPTSTR pmszReaders;
	LPTSTR pReader;

	m_SCardListReaders();
	pmszReaders = m_csReaderList.GetBuffer(0);

	// reader list is list of null terminated reader strings
	// list is terminated by double null character

	// get the first string
	pReader = pmszReaders;

	while('\0' != *pReader)
	{
		// add the string to the combo box
		combobox->AddString(pReader);

		// Advance to next value in string
		pReader = pReader + strlen(pReader);
	}

}

CString SCardManager::m_GetPCSCErrorString(LONG lReturn)
{

	switch(lReturn)
	{
        case 0x80100001:
                return "SCARD_F_INTERNAL_ERROR";
                break;

        case 0x80100002:
                return "SCARD_E_CANCELLED";
                break;

        case 0x80100003:
                return "SCARD_E_INVALID_HANDLE";
                break;

        case 0x80100004:
                return "SCARD_E_INVALID_PARAMETER";
                break;

        case 0x80100005:
                return "SCARD_E_INVALID_TARGET";
                break;

        case 0x80100006:
                return "SCARD_E_NO_MEMORY";
                break;

        case 0x80100007:
                return "SCARD_F_WAITED_TOO_LONG";
                break;

        case 0x80100008:
                return "SCARD_E_INSUFFICIENT_BUFFER";
                break;

        case 0x80100009:
                return "SCARD_E_UNKNOWN_READER";
                break;

        case 0x8010000A:
                return "SCARD_E_TIMEOUT";
                break;

        case 0x8010000B:
                return "SCARD_E_SHARING_VIOLATION";
                break;

        case 0x8010000C:
                return "SCARD_E_NO_SMARTCARD";
                break;

        case 0x8010000D:
                return "SCARD_E_UNKNOWN_CARD";
                break;

        case 0x8010000E:
                return "SCARD_E_CANT_DISPOSE";
                break;

        case 0x8010000F:
                return "SCARD_E_PROTO_MISMATCH";
                break;

        case 0x80100010:
                return "SCARD_E_NOT_READY";
                break;

        case 0x80100011:
                return "SCARD_E_INVALID_VALUE";
                break;

        case 0x80100012:
                return "SCARD_E_SYSTEM_CANCELLED";
                break;

        case 0x80100013:
                return "SCARD_F_COMM_ERROR";
                break;

        case 0x80100014:
                return "SCARD_F_UNKNOWN_ERROR";
                break;

        case 0x80100015:
                return "SCARD_E_INVALID_ATR";
                break;

        case 0x80100016:
                return "SCARD_E_NOT_TRANSACTED";
                break;

        case 0x80100017:
                return "SCARD_E_READER_UNAVAILABLE";
                break;

        case 0x80100018:
                return "SCARD_P_SHUTDOWN";
                break;

        case 0x80100019:
                return "SCARD_E_PCI_TOO_SMALL";
                break;

        case 0x8010001A:
                return "SCARD_E_READER_UNSUPPORTED";
                break;

        case 0x8010001B:
                return "SCARD_E_DUPLICATE_READER";
                break;

        case 0x8010001C:
                return "SCARD_E_CARD_UNSUPPORTED";
                break;

        case 0x8010001D:
                return "SCARD_E_NO_SERVICE";
                break;

        case 0x8010001E:
                return "SCARD_E_SERVICE_STOPPED";
                break;

        case 0x8010001F:
                return "SCARD_E_UNEXPECTED";
                break;

        case 0x80100020:
                return "SCARD_E_ICC_INSTALLATION";
                break;

        case 0x80100021:
                return "SCARD_E_ICC_CREATEORDER";
                break;

        case 0x80100022:
                return "SCARD_E_UNSUPPORTED_FEATURE";
                break;

        case 0x80100023:
                return "SCARD_E_DIR_NOT_FOUND";
                break;

        case 0x80100024:
                return "SCARD_E_FILE_NOT_FOUND";
                break;

        case 0x80100025:
                return "SCARD_E_NO_DIR";
                break;

        case 0x80100026:
                return "SCARD_E_NO_FILE";
                break;

        case 0x80100027:
                return "SCARD_E_NO_ACCESS";
                break;

        case 0x80100028:
                return "SCARD_E_WRITE_TOO_MANY";
                break;

        case 0x80100029:
                return "SCARD_E_BAD_SEEK";
                break;

        case 0x8010002A:
                return "SCARD_E_INVALID_CHV";
                break;

        case 0x8010002B:
                return "SCARD_E_UNKNOWN_RES_MNG";
                break;

        case 0x8010002C:
                return "SCARD_E_NO_SUCH_CERTIFICATE";
                break;

        case 0x8010002D:
                return "SCARD_E_CERTIFICATE_UNAVAILABLE";
                break;

        case 0x8010002E:
                return "SCARD_E_NO_READERS_AVAILABLE";
                break;

        case 0x80100065:
                return "SCARD_W_UNSUPPORTED_CARD";
                break;

        case 0x80100066:
                return "SCARD_W_UNRESPONSIVE_CARD";
                break;

        case 0x80100067:
                return "SCARD_W_UNPOWERED_CARD";
                break;

        case 0x80100068:
                return "SCARD_W_RESET_CARD";
                break;

        case 0x80100069:
                return "SCARD_W_REMOVED_CARD";
                break;

        case 0x8010006A:
                return "SCARD_W_SECURITY_VIOLATION";
                break;

        case 0x8010006B:
                return "SCARD_W_WRONG_CHV";
                break;

        case 0x8010006C:
                return "SCARD_W_CHV_BLOCKED";
                break;

        case 0x8010006D:
                return "SCARD_W_EOF";
                break;

        case 0x8010006E:
                return "SCARD_W_CANCELLED_BY_USER";
                break;

        case 0x0000007B:
                return "INACCESSIBLE_BOOT_DEVICE";
                break;

	default:
		return "Invalid Error Code";

	}

}
