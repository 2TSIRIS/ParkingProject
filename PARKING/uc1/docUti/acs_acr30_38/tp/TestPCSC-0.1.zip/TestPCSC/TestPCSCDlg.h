// TestPCSCDlg.h : header file
//

#if !defined(AFX_TESTPCSCDLG_H__F6294A37_E36D_4A66_B1E3_AFFF077147A7__INCLUDED_)
#define AFX_TESTPCSCDLG_H__F6294A37_E36D_4A66_B1E3_AFFF077147A7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

extern SCardManager SCManager;

/////////////////////////////////////////////////////////////////////////////
// CTestPCSCDlg dialog

class CTestPCSCDlg : public CDialog
{
// Construction
public:
	CTestPCSCDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestPCSCDlg)
	enum { IDD = IDD_TESTPCSC_DIALOG };
	CComboBox	m_ReaderSelectCombo;
	CString	m_Message;
	CString	m_SelectedReaderInfo;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestPCSCDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestPCSCDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSelchangeReaderSelectCombo();
	afx_msg void OnChangeEditMessage();
	afx_msg void OnConnectBtn();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTPCSCDLG_H__F6294A37_E36D_4A66_B1E3_AFFF077147A7__INCLUDED_)
