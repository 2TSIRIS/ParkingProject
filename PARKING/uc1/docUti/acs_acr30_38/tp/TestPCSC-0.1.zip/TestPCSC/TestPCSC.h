// TestPCSC.h : main header file for the TESTPCSC application
//

#if !defined(AFX_TESTPCSC_H__0169A0D3_6E4E_4132_9CE7_D82DEE2CC26C__INCLUDED_)
#define AFX_TESTPCSC_H__0169A0D3_6E4E_4132_9CE7_D82DEE2CC26C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

// PC/SC support
#include "winscard.h"
#include "SCardManager.h"	// Added by ClassView


/////////////////////////////////////////////////////////////////////////////
// CTestPCSCApp:
// See TestPCSC.cpp for the implementation of this class
//

class CTestPCSCApp : public CWinApp
{
public:
	CTestPCSCApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestPCSCApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestPCSCApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTPCSC_H__0169A0D3_6E4E_4132_9CE7_D82DEE2CC26C__INCLUDED_)
